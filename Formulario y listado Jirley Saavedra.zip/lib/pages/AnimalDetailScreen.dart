import 'package:flutter/material.dart';
import 'package:flutter_application/models/animal.dart';

class AnimalDetailScreen extends StatefulWidget {
  final Animal animal;
  final String heroTag;

  AnimalDetailScreen({required this.animal, required this.heroTag});

  @override
  _AnimalDetailScreenState createState() => _AnimalDetailScreenState();
}

class _AnimalDetailScreenState extends State<AnimalDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.animal.name),
      ),
      body: GestureDetector(
        onTap: () {
          Navigator.pop(context);
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Hero(
              tag: 'animal_image_${widget.animal.name}',
              child: Image.network(
                widget.animal.imageURL,
                width: 500,
                height: 400,
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                widget.animal.description,
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
