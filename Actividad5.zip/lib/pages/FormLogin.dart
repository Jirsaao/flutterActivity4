import 'package:flutter/material.dart';
import 'package:flutter_application/routing/routes.dart';

class FormLogin extends StatefulWidget {
  @override
  final String user;

  FormLogin({
    Key? key,
    required this.user,
  }) : super(key: key);

  State<StatefulWidget> createState() {
    return StateLogin();
  }
}

class StateLogin extends State<FormLogin> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Hero(
                tag: 'logo_discovery',
                child: Image.network(
                  "https://cdn.shopify.com/s/files/1/0558/6413/1764/files/Discovery_Channel_Logo_Design_History_Evolution_0_1024x1024.jpg?v=1694070082",
                  height: 300,
                  width: 400,
                ),
              ),
              TextFormField(
                controller: userController,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Por favor, ingresa el usuario';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Usuario',
                ),
              ),
              TextFormField(
                controller: passwordController,
                validator: (value) {
                  // if (value!.isEmpty || value.length < 8) {
                  //   return 'La contraseña debe tener al menos 8 caracteres';
                  // }
                  // if (!_containsLetterAndNumber(value)) {
                  //   return 'La contraseña debe contener letras y números';
                  // }
                  return null;
                },
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Contraseña',
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    if (userController.text == 'a' &&
                        passwordController.text == 'a') {
                      //con 'pushReplacementNamed' remplaza la ruta de inicio de sesion y confirma los datos de navegacion
                      Navigator.pushReplacementNamed(context, Routes.pageUser);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content:
                              Text('Error al ingresar, verifica los datos.'),
                        ),
                      );
                    }
                  }
                },
                child: Text('Enviar'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool _containsLetterAndNumber(String value) {
    return RegExp(r'(?=.*[A-Za-z])(?=.*[0-9])').hasMatch(value);
  }
}

bool checkData(String user, String password) {
  String enteredUser = userController.text;
  String enteredPass = passwordController.text;
  return enteredUser == user && enteredPass == password;
}

TextEditingController userController = TextEditingController();
TextEditingController passwordController = TextEditingController();
