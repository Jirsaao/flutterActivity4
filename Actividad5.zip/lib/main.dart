import 'package:flutter/material.dart';
import 'package:flutter_application/pages/SplashPage.dart';
import 'package:flutter_application/routing/routes.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //configuracion d splash en el main
      home: const SplashPage(),
      routes: appRoutes,
    );
  }
}
